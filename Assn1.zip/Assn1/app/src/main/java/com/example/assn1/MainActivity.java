package com.example.assn1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText input1,input2;
    TextView output,item;
    Button press;
    Spinner spin;
    ArrayList<String> arr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input1=findViewById(R.id.editTextTextPersonName);
        input2=findViewById(R.id.editTextTextPersonName2);
        output=findViewById(R.id.textView);
        item=findViewById(R.id.tvItem);
        press=findViewById(R.id.button);
        spin=findViewById(R.id.spinner);
        arr=new ArrayList<>();
        arr.add("Add");
        arr.add("Sub");
        arr.add("Mul");
        arr.add("Div");

        ArrayAdapter ad=new ArrayAdapter(MainActivity.this,R.layout.item,R.id.tvItem,arr);
        spin.setAdapter(ad);
        press.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a=Integer.parseInt(input1.getText().toString());
                int b=Integer.parseInt(input2.getText().toString());
                if(spin.getSelectedItem().toString()=="Add"){
                    output.setText("Sum: "+(a+b));
                }
                else if(spin.getSelectedItem().toString()=="Sub"){
                    output.setText("Sub: "+(a-b));
                }
                else if(spin.getSelectedItem().toString()=="Mul"){
                    output.setText("Mul: "+(a*b));
                }
                else if(spin.getSelectedItem().toString()=="Div"){
                    if(b==0){
                        output.setText("Cannot divide a number by zero");
                    }
                    else{
                    output.setText("Div: "+(a/b)+" R "+(a%b));
                    }
                }
                else{
                    output.setText("Invalid!");
                }
            }
        });

    }
}